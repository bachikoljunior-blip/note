収益プロジェクト iPhoneハンドオフ

1. 外側の note_iPhone_handoff.zip をiPhoneのFilesで1回だけタップして展開します。
2. 展開フォルダの START_HERE.html を長押しし、共有または「このアプリで開く」からSafariで開きます。
3. 公開済みnoteの告知、無料note記事、BOOTHの順に進めます。
4. AI_trivia_shorts_creator_kit_v1.1.zip は展開せず、そのままBOOTHの商品ファイルに選びます。
5. Gumroadは操作できる時だけチャットへ「Gumroad認証開始」と送ります。期限切れを避けるためdevice codeは事前発行しません。

HTMLが動かない場合は、同梱の copy/note_title.txt、copy/note_body.md、copy/booth_title.txt、copy/booth_description.md、copy/booth_tags.txt を個別に開いてコピーします。
